Ext.define('LeetSkills', {
    makeItBetter: function() {
        alert("I don't care - I'm going to revert your commits!");
    }
});