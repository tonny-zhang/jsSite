//This is a mixin, which we add to the class in Developer.js (see example 3)
Ext.define('MadSkills', {
    hackAway: function() {
        alert('I swear Abe, it worked 20 minutes ago');
    }
});