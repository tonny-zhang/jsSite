//This is the simplest class, used in example 1. This class does not depend on any others, so the example is run immediately
//after it is loaded
Ext.define('Product', {
    config: {
        name: 'Product Name'
    }
});